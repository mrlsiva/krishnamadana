<?php $__env->startSection('section'); ?>
    <div class="section-header mb-4">
        Orders List
    </div>
    <div class="rounded-xl relative overflow-auto">
        <div class="shadow-sm overflow-hidden">
            <table class="w-full table-auto border-collapse bg-white">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="bg-grid-slate-100 border-b p-4 text-slate-800 text-left font-medium">#</th>
                        <th class="border-b p-4 text-slate-800 text-left font-medium">Order &amp; Payment ID</th>
                        <th class="border-b p-4 text-slate-800 text-left font-medium">Items</th>
                        <th class="border-b p-4 text-slate-800 text-left font-medium">Amount and Discount</th>
                        <th class="border-b p-4 text-slate-800 text-left font-medium">Order Date</th>
                        <th class="border-b p-4 text-slate-800 text-left font-medium">Shipping Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($orders->count())): ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.no-results-table','data' => ['colspan' => '6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.no-results-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => '6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="p-4"><?php echo e($loop->iteration); ?>.</td>
                            <td class="p-4"><?php echo e($order->order_id); ?><br/><?php echo e($order->payment_id); ?></td>
                            <td class="p-4">
                                <div class="flex flex-col">
                                <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex flex-col mb-4">
                                        <p><strong><?php echo e($item->product->name); ?></strong></p>
                                        <p><?php echo e($item->variant_name); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            </td>
                            <td class="p-4">
                                Net Amount: <?php echo e($order->amount); ?><br/>
                                Discount: <?php echo e($order->discount); ?>

                            </td>
                            <td class="p-4">
                                <?php echo e($order->created_at->format('j F, Y')); ?>

                            </td>
                            <td class="p-4">
                                <div class=""><strong><?php echo e($order->shipping_address->name); ?></strong>,
                                    <br/><?php echo e($order->shipping_address->address_line1); ?>,<br/>
                                    <?php if($order->shipping_address->address_line2): ?>
                                    <?php echo e($order->shipping_address->address_line2); ?>,<br/>
                                    <?php endif; ?>
                                    <?php if($order->shipping_address->landmark): ?>
                                    <?php echo e($order->shipping_address->landmark); ?>,
                                    <br/>
                                    <?php endif; ?>
                                    <?php echo e($order->shipping_address->city); ?>,
                                    <br/><?php echo e($order->shipping_address->state->name); ?>, <?php echo e($order->shipping_address->pincode); ?>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/admin/order-list.blade.php ENDPATH**/ ?>