<svg xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg"
    xmlns="http://www.w3.org/2000/svg" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
    xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" viewBox="0 0 256 256" version="1.1" id="svg8"
    inkscape:version="0.92.3 (2405546, 2018-03-11)" sodipodi:docname="gala-search.svg" inkscape:export-xdpi="96"
    inkscape:export-ydpi="96">
    <title id="title851">Gala icon set</title>
    <defs id="defs2" />
    <sodipodi:namedview id="base" pagecolor="#ffffff" bordercolor="#666666" borderopacity="1.0"
        inkscape:pageopacity="0.0" inkscape:pageshadow="2" inkscape:zoom="1.979899" inkscape:cx="91.433761"
        inkscape:cy="130.1178" inkscape:document-units="px" inkscape:current-layer="layer1"
        inkscape:document-rotation="0" showgrid="true" units="px" inkscape:pagecheckerboard="true"
        inkscape:showpageshadow="false" inkscape:window-width="1854" inkscape:window-height="1016"
        inkscape:window-x="66" inkscape:window-y="27" inkscape:window-maximized="1" inkscape:snap-page="true"
        inkscape:snap-text-baseline="true" inkscape:snap-center="true" inkscape:snap-others="true"
        inkscape:snap-object-midpoints="true" inkscape:snap-midpoints="true" inkscape:snap-smooth-nodes="true"
        inkscape:snap-intersection-paths="true" inkscape:object-paths="true" inkscape:snap-bbox="true"
        inkscape:bbox-paths="true" inkscape:bbox-nodes="true" inkscape:snap-bbox-midpoints="true"
        inkscape:snap-bbox-edge-midpoints="true" showguides="true" inkscape:guide-bbox="true">
        <inkscape:grid type="xygrid" id="grid860" empspacing="16" />
    </sodipodi:namedview>
    <metadata id="metadata5">
        <rdf:RDF>
            <cc:Work rdf:about="">
                <dc:format>image/svg+xml</dc:format>
                <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
                <dc:title>Gala icon set</dc:title>
                <dc:source>https://github.com/sisyphusion/gala-icons</dc:source>
                <dc:subject>
                    <rdf:Bag />
                </dc:subject>
                <dc:creator>
                    <cc:Agent>
                        <dc:title>Jake Wells</dc:title>
                    </cc:Agent>
                </dc:creator>
                <dc:contributor>
                    <cc:Agent>
                        <dc:title />
                    </cc:Agent>
                </dc:contributor>
            </cc:Work>
        </rdf:RDF>
    </metadata>
    <g inkscape:label="icon" inkscape:groupmode="layer" id="layer1">
        <path
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
            d="m 89.074145,145.23139 -68.17345,68.17344" id="path895" sodipodi:nodetypes="cc"
            inkscape:connector-curvature="0" />
        <path
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
            d="M 111.27275,167.42999 43.099304,235.60344" id="path897" sodipodi:nodetypes="cc"
            inkscape:connector-curvature="0" />
        <path id="path878-6"
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none"
            d="m 43.099305,235.60344 a 15.696788,15.696788 0 0 1 -22.19861,0" inkscape:connector-curvature="0" />
        <path id="path878-3-7"
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none"
            d="m 20.900695,213.40483 a 15.696788,15.696788 0 0 0 0,22.19861" inkscape:connector-curvature="0" />
        <path
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none"
            d="M 240.65575,86.483932 A 70.635544,70.635544 0 0 1 170.0202,157.11948 70.635544,70.635544 0 0 1 99.384659,86.483932 70.635544,70.635544 0 0 1 170.0202,15.848389 70.635544,70.635544 0 0 1 240.65575,86.483932 Z"
            id="path927" />
        <path
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
            d="m 89.074145,145.23139 22.198605,22.1986" id="path929" inkscape:connector-curvature="0" />
        <path
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
            d="m 100.17344,156.33068 19.89988,-19.89987" id="path931" sodipodi:nodetypes="cc"
            inkscape:connector-curvature="0" />
        <path
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
            d="m 70.126446,164.17908 22.198606,22.1986" id="path929-6" inkscape:connector-curvature="0" />
        <path id="path996"
            style="fill:none;stroke:currentColor;stroke-width:16;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none"
            d="M 209.26216,86.483936 A 39.241967,39.241967 0 0 1 170.0202,125.7259" inkscape:connector-curvature="0" />
    </g>
</svg>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/components/icons/search.blade.php ENDPATH**/ ?>