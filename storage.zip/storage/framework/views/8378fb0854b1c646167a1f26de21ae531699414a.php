<?php $__env->startSection('section'); ?>
    <div class="section-header">
        User List
    </div>
    <a href="<?php echo e(route('admin.user.create')); ?>" class="inline-block my-4 bg-green-600 text-white px-4 py-2 rounded">Create
        User</a>
        <div class="rounded-xl relative overflow-auto">
            <div class="shadow-sm overflow-hidden">
                <table class="w-full table-auto border-collapse bg-white">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="bg-grid-slate-100 border-b p-4 text-slate-800 text-left font-medium">#</th>
                            <th class="border-b p-4 text-slate-800 text-left font-medium">Name</th>
                            <th class="border-b p-4 text-slate-800 text-left font-medium">Email</th>
                            <th class="border-b p-4 text-slate-800 text-left font-medium">Mobile</th>
                            <th class="border-b p-4 text-slate-800 text-left font-medium">Account Created At</th>
                            <th class="border-b p-4 text-slate-800 text-left font-medium">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($users->count())): ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.no-results-table','data' => ['colspan' => '6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.no-results-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['colspan' => '6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="p-4"><?php echo e($loop->iteration); ?>.</td>
                                <td class="p-4"><?php echo e($user->name); ?></td>
                                <td class="p-4"><?php echo e($user->email); ?></td>
                                <td class="p-4"><?php echo e($user->mobile); ?></td>
                                <td class="p-4">
                                    <?php echo e($user->created_at->format('j F, Y')); ?>

                                </td>
                                <td class="p-4">
                                    <div class="flex">
                                        
                                        
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/admin/user-list.blade.php ENDPATH**/ ?>