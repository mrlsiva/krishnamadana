<?php $__env->startSection('title'); ?>
    - Shop Online for Latest
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <?php if (isset($component)) { $__componentOriginal661ad7381d7069a2e4ced1f814e0155733d5641a = $component; } ?>
<?php $component = App\View\Components\Public\Home\Carousel::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.home.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Home\Carousel::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal661ad7381d7069a2e4ced1f814e0155733d5641a)): ?>
<?php $component = $__componentOriginal661ad7381d7069a2e4ced1f814e0155733d5641a; ?>
<?php unset($__componentOriginal661ad7381d7069a2e4ced1f814e0155733d5641a); ?>
<?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('public.home.show-categories', [])->html();
} elseif ($_instance->childHasBeenRendered('YVYRwKu')) {
    $componentId = $_instance->getRenderedChildComponentId('YVYRwKu');
    $componentTag = $_instance->getRenderedChildComponentTagName('YVYRwKu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YVYRwKu');
} else {
    $response = \Livewire\Livewire::mount('public.home.show-categories', []);
    $html = $response->html();
    $_instance->logRenderedChild('YVYRwKu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('public.home.best-sellers', [])->html();
} elseif ($_instance->childHasBeenRendered('f0DdNFl')) {
    $componentId = $_instance->getRenderedChildComponentId('f0DdNFl');
    $componentTag = $_instance->getRenderedChildComponentTagName('f0DdNFl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('f0DdNFl');
} else {
    $response = \Livewire\Livewire::mount('public.home.best-sellers', []);
    $html = $response->html();
    $_instance->logRenderedChild('f0DdNFl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php if (isset($component)) { $__componentOriginal2ca857dd875a7a805fafaf70ac80312f70622b9c = $component; } ?>
<?php $component = App\View\Components\Public\Home\Banner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.home.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Home\Banner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ca857dd875a7a805fafaf70ac80312f70622b9c)): ?>
<?php $component = $__componentOriginal2ca857dd875a7a805fafaf70ac80312f70622b9c; ?>
<?php unset($__componentOriginal2ca857dd875a7a805fafaf70ac80312f70622b9c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal081bf8af493ad0fb67d960363b5a80f85a25cbba = $component; } ?>
<?php $component = App\View\Components\Public\Home\OurPromises::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.home.our-promises'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Home\OurPromises::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal081bf8af493ad0fb67d960363b5a80f85a25cbba)): ?>
<?php $component = $__componentOriginal081bf8af493ad0fb67d960363b5a80f85a25cbba; ?>
<?php unset($__componentOriginal081bf8af493ad0fb67d960363b5a80f85a25cbba); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            new Swiper(".swiper", {
                loop: true,
                speed: 500,
                direction: "horizontal",
                autoplay: {
                    delay: 3000,
                },
                effect: "fade",
                fadeEffect: {
                    crossFade: true,
                },
                init: true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zzg3h386vagh/public_html/resources/views/public/home.blade.php ENDPATH**/ ?>