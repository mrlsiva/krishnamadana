<?php $__env->startSection('title'); ?> Admin Login <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="h-screen h-full flex items-center justify-center">
        <div class="border rounded-lg shadow p-8 m-4 w-full md:w-1/3">
            <h1 class="mb-8 text-center font-bold text-2xl">Login</h1>
            <?php if($errors->any()): ?>
                <div class="text-white px-6 py-4 border-0 rounded relative mb-4 bg-red-400 flex">
                    <span class="text-xl inline-block mr-5 align-middle">
                        <i class="fas fa-bell"></i>
                    </span>
                    <ul class="inline-block align-top mr-8">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="relative mb-4">
                    <label for="username" class="font-semibold block mb-2 text-slate-800">Username</label>
                    <input name="username" id="username" type="text" class="peer w-full py-3 border px-2 rounded"
                        placeholder="Enter username" value="<?php echo e(old('username')); ?>" required />
                </div>
                <div class="relative">
                    <label for="password" class="font-semibold block mb-2 text-slate-800">Password</label>
                    <input name="password" id="password" type="password" class="peer w-full py-3 border px-2 rounded"
                        placeholder="Enter password" required />
                </div>
                <button class="primary mt-8 text-center w-full bg-primary text-on-primary py-4">Login</button>
            </form>
        </div>
    </section>
<?php $__env->startSection('body'); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zzg3h386vagh/public_html/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>