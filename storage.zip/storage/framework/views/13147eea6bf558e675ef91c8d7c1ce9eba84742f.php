<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name')); ?> <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>

<body class="antialiased">
    <?php if (isset($component)) { $__componentOriginal0de2c6fa942fcc3bd3edd5d1c75441d740d736d9 = $component; } ?>
<?php $component = App\View\Components\Public\Common\Announcement::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.common.announcement'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Common\Announcement::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de2c6fa942fcc3bd3edd5d1c75441d740d736d9)): ?>
<?php $component = $__componentOriginal0de2c6fa942fcc3bd3edd5d1c75441d740d736d9; ?>
<?php unset($__componentOriginal0de2c6fa942fcc3bd3edd5d1c75441d740d736d9); ?>
<?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('public.common.header', [])->html();
} elseif ($_instance->childHasBeenRendered('5BhzeXC')) {
    $componentId = $_instance->getRenderedChildComponentId('5BhzeXC');
    $componentTag = $_instance->getRenderedChildComponentTagName('5BhzeXC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5BhzeXC');
} else {
    $response = \Livewire\Livewire::mount('public.common.header', []);
    $html = $response->html();
    $_instance->logRenderedChild('5BhzeXC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo $__env->yieldContent('main'); ?>
    <?php if (isset($component)) { $__componentOriginal058813736e97b1328de22767778c6b0d654e0e30 = $component; } ?>
<?php $component = App\View\Components\Public\Common\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('public.common.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Public\Common\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal058813736e97b1328de22767778c6b0d654e0e30)): ?>
<?php $component = $__componentOriginal058813736e97b1328de22767778c6b0d654e0e30; ?>
<?php unset($__componentOriginal058813736e97b1328de22767778c6b0d654e0e30); ?>
<?php endif; ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-alert::components.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('livewire-alert::scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</body>
<?php echo $__env->yieldContent('scripts'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-ui-modal')->html();
} elseif ($_instance->childHasBeenRendered('BhfE4fF')) {
    $componentId = $_instance->getRenderedChildComponentId('BhfE4fF');
    $componentTag = $_instance->getRenderedChildComponentTagName('BhfE4fF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BhfE4fF');
} else {
    $response = \Livewire\Livewire::mount('livewire-ui-modal');
    $html = $response->html();
    $_instance->logRenderedChild('BhfE4fF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</html>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/public/base.blade.php ENDPATH**/ ?>