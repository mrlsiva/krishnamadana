<div class="collections-grid mx-12 my-8">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="collection relative overflow-hidden">
            <img src="<?php echo e($category->media[0]->original_url); ?>" class="w-full" alt="">
            <div class="collection__content">
                <h2><?php echo e($category->name); ?></h2>
                <a href="<?php echo e(route('home.collections', ['slug' => $category->slug])); ?>" class="primary-link">Shop
                    Now</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/home/show-categories.blade.php ENDPATH**/ ?>