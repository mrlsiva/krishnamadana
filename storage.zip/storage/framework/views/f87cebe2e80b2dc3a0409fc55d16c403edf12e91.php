<div class="swiper relative">
    <div class="swiper-wrapper">
        <img src="/images/home/slider-1.jpg" class="swiper-slide" alt="">
        <img src="/images/home/slider-2.jpg" class="swiper-slide" alt="">
    </div>
    <div class="page-dots absolute top-4 left-4 flex">
        <div class="dot w-4 h-4 rounded-full border-2 border-stone-900"></div>
    </div>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/components/public/home/carousel.blade.php ENDPATH**/ ?>