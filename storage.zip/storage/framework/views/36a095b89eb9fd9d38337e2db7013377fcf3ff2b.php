<section class="p-4 our-promises flex flex-col items-center justify-center">
    <h2 class="mb-4">Our Promises</h2>
    <div class="w-full flex items-center justify-center">
        <div class="flex flex-col items-center justify-center mx-8">
            <img src="images/home/promise-1.png" alt="">
            <p>Premium Quality</p>
        </div>
        <div class="flex flex-col items-center justify-center mx-8">
            <img src="images/home/promise-2.png" alt="">
            <p>Original Designs</p>
        </div>
        <div class="flex flex-col items-center justify-center mx-8">
            <img src="images/home/promise-3.png" alt="">
            <p>Secured Payment</p>
        </div>
        <div class="flex flex-col items-center justify-center mx-8">
            <img src="images/home/promise-4.png" alt="">
            <p>Handmade with love</p>
        </div>
        <div class="flex flex-col items-center justify-center mx-8">
            <img src="images/home/promise-5.png" alt="">
            <p>Free Shipping</p>
        </div>
    </div>
</section>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/components/public/home/our-promises.blade.php ENDPATH**/ ?>