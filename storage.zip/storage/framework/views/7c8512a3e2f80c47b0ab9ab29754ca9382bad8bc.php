<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="flex">
        <nav class="main-nav">
            <ul class="space-y-2">
                <li>
                    <a href="<?php echo e(route('admin.store.productList')); ?>" class="text-center flex flex-col items-center justify-center <?php if(Route::is('admin.store.*')): ?> active <?php endif; ?>">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.store','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> <span>Store</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.order.list')); ?>" class="text-center flex flex-col items-center justify-center <?php if(Route::is('admin.order.*')): ?> active <?php endif; ?>">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.store','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> <span>Orders</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.user.list')); ?>" class="text-center flex flex-col items-center justify-center <?php if(Route::is('admin.user.*')): ?> active <?php endif; ?>">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.store','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> <span>Users</span>
                    </a>
                </li>
            </ul>
        </nav>
        <nav class="secondary-nav">
            <?php if(Route::is('admin.store.*')): ?>
            <ul>
                <li>
                    <a href="<?php echo e(route('admin.store.productList')); ?>" class="<?= Route::currentRouteName() == 'admin.store.productList' ? 'active' : ''; ?>">Products</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.store.createProduct')); ?>" class="<?= Route::currentRouteName() == 'admin.store.createProduct' ? 'active' : ''; ?>">Create
                        Product</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.store.categoryList')); ?>" class="<?= Route::currentRouteName() == 'admin.store.categoryList' ? 'active' : ''; ?>">Categories</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.store.createCategory')); ?>" class="<?= Route::currentRouteName() == 'admin.store.createCategory' ? 'active' : ''; ?>">Create
                        Category</a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('admin.store.createProductVariation')); ?>" class="<?= Route::currentRouteName() == 'admin.store.createProductVariation' ? 'active' : ''; ?>">Product Variations</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.store.createVariationOption')); ?>" class="<?= Route::currentRouteName() == 'admin.store.createVariationOption' ? 'active' : ''; ?>">Variation Options</a>
                </li>
            </ul>
            <?php endif; ?>
            <?php if(Route::is('admin.user.*')): ?>
            <ul>
                <li>
                    <a href="<?php echo e(route('admin.user.list')); ?>" class="<?= Route::currentRouteName() == 'admin.user.list' ? 'active' : ''; ?>">User List</a>
                    <a href="<?php echo e(route('admin.user.create')); ?>" class="<?= Route::currentRouteName() == 'admin.user.create' ? 'active' : ''; ?>">Create User</a>
                </li>
            </ul>
            <?php endif; ?>
            <?php if(Route::is('admin.order.*')): ?>
            <ul>
                <li>
                    <a href="<?php echo e(route('admin.order.list')); ?>" class="<?= Route::currentRouteName() == 'admin.order.list' ? 'active' : ''; ?>">Order List</a>
                </li>
            </ul>
            <?php endif; ?>
        </nav>
        <div class="page-content flex-1">
            <div class="header">
                <a href="">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </a>
            </div>
            <section class="section-content flex-1 p-4">
                <?php echo $__env->yieldContent('section'); ?>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zzg3h386vagh/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>