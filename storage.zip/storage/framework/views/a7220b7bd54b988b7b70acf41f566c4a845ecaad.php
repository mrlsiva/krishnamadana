<div class="w-full md:w-4/5 mx-auto my-4">
    <h2 class="text-center text-xl font-semibold">Cart</h2>
    <?php if(Cart::isEmpty()): ?>
        <div class="my-24 flex flex-col items-center justify-center">
            <p class="mb-4 text-xl">Your cart is empty.</p>
            <a href="<?php echo e(route('home')); ?>" class="cta-link px-8 py-3">Shop Our Products</a>
        </div>
    <?php else: ?>
        <div class="flex flex-col my-8">
            <div class="flex border-b items-center justify-between">
                <div class="py-2 basis-3/5">Product</div>
                <div class="py-2 basis-1/5">Quantity</div>
                <div class="py-2 basis-1/5">Price</div>
            </div>
            <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between py-4">
                    <div class="py-2 basis-3/5 flex items-center">
                        <img src="<?php echo e($item->model->media[0]->original_url); ?>" alt=""
                            class="w-36 h-36 object-cover" />
                        <div class="flex flex-col ms-4">
                            <p class="text-xl"><?php echo e($item->name); ?></p>
                            <p class="text-gray-500"><?php echo e($item->attributes['display_name']); ?></p>
                            <p class="text-gray-500">Rs. <?php echo e($item->attributes['selected_variant']['amount']); ?></p>
                        </div>
                    </div>
                    <div class="py-2 basis-1/5">
                        <div class="border w-24 flex items-center p-2 text-gray-600">
                            <button wire:click="reduce_quantity(<?php echo e($item['id']); ?>)">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.minus','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.minus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </button>
                            <div class="flex-1 text-center"><?php echo e($item->quantity); ?></div>
                            <button wire:click="increase_quantity(<?php echo e($item['id']); ?>)">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.plus','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </button>
                        </div>
                        <button class="underline mt-2 w-24 text-center"
                            wire:click="remove_item(<?php echo e($item['id']); ?>)">Remove</button>
                    </div>
                    <div class="py-2 basis-1/5">Rs. <?php echo e(number_format($item->getPriceSum(), 2)); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center border-t py-4">
                
                <div class="flex basis-4/5"></div>
                <div class="flex flex-col basis-1/5">
                    <p class="text-2xl mb-2">Total: Rs. <?php echo e(number_format(Cart::getTotal(), 2)); ?></p>
                    <a href="<?php echo e(route('home.checkout')); ?>" class="cta-link py-3 px-4 text-center">Checkout</a>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/order/cart.blade.php ENDPATH**/ ?>