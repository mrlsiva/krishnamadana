<div class="flex w-full md:w-10/12 mx-auto my-4">
    <div class="flex-1 flex flex-col">
        <div class="swiper product-swiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e($media->original_url); ?>" alt="<?php echo e($product->name); ?>" class="swiper-slide" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="flex mt-4 items-center justify-center flex-wrap">
            <?php $__currentLoopData = $product->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="w-32 h-32 object-cover ms-4 slider-thumb" src="<?php echo e($media->original_url); ?>"
                    alt="<?php echo e($product->name); ?>" data-index="<?php echo e($loop->index); ?>" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if (! (empty($product->additional_info))): ?>
            <div class="mt-6">
                <div class="collapsible border-y w-full border-gray-700" x-data="{ expanded: false }">
                    <button class="py-8 text-gray-700 text-xl text-left w-full flex items-center justify-between"
                        @click="expanded = !expanded">
                        Additional Information
                        <div class="inline-block" x-show="!expanded">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.plus','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                        <div class="inline-block" x-show="expanded">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.minus','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.minus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    </button>
                    <div class="pb-8" x-show="expanded" x-collapse>
                        <?php echo $product->additional_info; ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="flex-1 px-12">
        <h2 class="text-2xl text-center text-slate-600"><?php echo e($product->name); ?></h2>
        <div class="text-slate-800 my-4"><?php echo $product->description; ?></div>
        <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col mb-4">
                <p class="mb-4"><?php echo e($variation->name); ?>:</p>
                <div class="flex flex-wrap gap-y-4">
                    <?php $__currentLoopData = $variation->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="radio" name="<?php echo e($variation->id); ?>" class="hidden variation-input"
                            id="option=<?php echo e($option->id); ?>" <?php if($option_ids->contains($option->id)): echo 'checked'; endif; ?>
                            wire:change="on_variant_change(<?php echo e($loop->parent->index); ?>, <?php echo e($option->id); ?>)">
                        <label for="option=<?php echo e($option->id); ?>"
                            class="px-4 py-2 border me-4 text-slate-600 cursor-pointer variation-label select-none">
                            <?php echo e($option->value); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="price border-t pt-4 text-2xl text-slate-600">Rs. <?php echo e($selected_item->amount); ?></div>
        <button type="button" class="cta-link w-full py-3 my-4" wire:click="add_to_cart" wire:target="add_to_cart"
            wire:loading.attr="disabled">
            Add to Cart
        </button>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var swiper = new Swiper(".product-swiper", {
                loop: false,
                speed: 500,
                direction: "horizontal",
                autoplay: false,
                effect: "fade",
                fadeEffect: {
                    crossFade: true,
                },
                init: true,
            });
            document.querySelectorAll('.slider-thumb').forEach(function(item) {
                item.addEventListener('click', function(event) {
                    var index = event.target.getAttribute('data-index');
                    swiper.slideTo(+index);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/product/product-details.blade.php ENDPATH**/ ?>