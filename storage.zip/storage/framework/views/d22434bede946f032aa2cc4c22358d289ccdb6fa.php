<svg viewBox="0 0 480 480" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <title>edit</title>
    <path d="M200 360l150-150-80-80-150 150 80 80z m-140 60l110-30-80-80-30 110z m240-320l80 80 50-50-80-80-50 50z" />
</svg>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/components/icons/edit.blade.php ENDPATH**/ ?>