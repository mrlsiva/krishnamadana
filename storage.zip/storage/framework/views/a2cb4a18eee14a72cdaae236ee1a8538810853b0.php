<div class="flex w-full md:w-10/12 mx-auto p-8">
    <div class="flex flex-col basis-3/5 me-8">
        <h2 class="tracking-widest text-lg border-b pb-2 mb-4">Shipping Address</h2>

        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex border p-4 mb-4 cursor-pointer select-none <?php if($selected == $address->id): ?> border-green-600 bg-green-100 <?php else: ?> border-gray-500 <?php endif; ?>"
                wire:click="select_address(<?php echo e($address->id); ?>)">
                <input type="radio" class="me-5 mt-1 text-green-800" <?php if($selected == $address->id): echo 'checked'; endif; ?> />
                <div class=""><strong><?php echo e($address->name); ?></strong>, <?php echo e($address->address_line1); ?>,
                    <?php echo e($address->address_line2); ?>,
                    <?php echo e($address->landmark); ?>, <?php echo e($address->city); ?>, <?php echo e($address->state->name); ?>, <?php echo e($address->pincode); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <a href="javascript:void(0)" class="flex items-center justify-center mt-5" wire:click="open_address_modal">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.plus','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> Add New Address
        </a>
    </div>
    <div class="basis-2/5 flex flex-col">
        <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center">
                <div class="relative">
                    <img src="<?php echo e($item->model->media[0]->original_url); ?>" alt=""
                        class="w-24 h-24 object-cover rounded" />
                    <div class="absolute -top-4 -right-4 bg-gray-600 rounded px-2 py-1 text-white text-sm">
                        <?php echo e($item->quantity); ?>

                    </div>
                </div>
                <div class="flex-1 flex flex-col justify-center ml-5">
                    <p class="text-base"><?php echo e($item->name); ?></p>
                    <p class="text-gray-500"><?php echo e($item->attributes['display_name']); ?></p>
                </div>
                <div class="">Rs. <?php echo e(number_format($item->getPriceSum(), 2)); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="flex my-5">
            <div class="flex-1 me-5">
                <input type="text" placeholder="Enter coupon code..."
                    class="peer input w-full border-gray-500 rounded" />
            </div>
            <button class="px-4 bg-yellow-500 rounded text-white">Apply</button>
        </div>
        <div class="flex flex-col tracking-wider">
            <div class="flex justify-evenly mb-2">
                <div class="flex-1">Subtotal</div>
                <div class="text-right flex-1">Rs. <?php echo e(number_format(Cart::getSubTotal(), 2)); ?></div>
            </div>
            <div class="flex justify-evenly mb-2">
                <div class="flex-1">Shipping Charges</div>
                <div class="text-right flex-1">Rs. <?php echo e(number_format(Cart::getTotal() - Cart::getSubTotal(), 2)); ?></div>
            </div>
            <div class="flex justify-evenly text-lg">
                <div class="flex-1">Total</div>
                <div class="text-right flex-1">Rs. <?php echo e(number_format(Cart::getTotal(), 2)); ?></div>
            </div>
            <div class="mt-4">
                <textarea name="note" id="note" rows="3" class="w-full resize-none"
                    placeholder="Add any notes for your delivery and order..." wire:model.defer="notes"></textarea>
            </div>
        </div>
        <button class="mt-4 cta-link py-3" wire:click="continue_checkout">Continue Payment</button>
        
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        Livewire.on('openCheckout', function(options) {
            var checkout = new Razorpay(options);
            checkout.open();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/order/checkout.blade.php ENDPATH**/ ?>