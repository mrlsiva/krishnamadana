<div class="flex flex-col">
    <div class="flex my-4 w-full items-center">
        <div class="flex-1"></div>
        <div class="logo mb-2">
            <a href="<?php echo e(route('home')); ?>"><img src="/images/logo.png" alt=""></a>
        </div>
        <div class="flex-1">
            <nav class="flex justify-end mx-8">
                <?php if(auth()->guard('web')->check()): ?>
                    <a href="<?php echo e(route('home.account')); ?>" class="px-4">Account</a>
                <?php else: ?>
                    <a href="<?php echo e(route('home.login')); ?>" class="px-4">Account</a>
                <?php endif; ?>
                <a href="" class="px-4">Search</a>
                <a href="<?php echo e(route('home.cart')); ?>" class="px-4">Cart (<?php echo e(Cart::getTotalQuantity()); ?>)</a>
            </nav>
        </div>
    </div>
    <div class="flex w-full border-b pb-4">
        <nav class="w-full">
            <ul class="flex items-center justify-center w-full">
                <li><a href="<?php echo e(route('home')); ?>" class="p-4 nav-link">Home</a></li>
                <li class="relative" x-data="{ open: false }" @mouseover.away="open=false">
                    <a href="" class="p-4 nav-link" @mouseover="open=true">Shop</a>
                    <ul class="dropdown-menu shop-menu" x-show="open">
                        <a href="">Shop All</a>
                        <a href="">Kurta Sets</a>
                        <a href="">Saree All</a>
                        <a href="">Blouses</a>
                    </ul>
                </li>
                
                <li><a href="" class="p-4 nav-link">About Us</a></li>
                <li><a href="" class="p-4 nav-link">Contact Us</a></li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/common/header.blade.php ENDPATH**/ ?>