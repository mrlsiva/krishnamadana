<div class="">
    <div class="section-header mb-4">
        Create Category
    </div>
    <form wire:submit.prevent="save">
        <?php echo csrf_field(); ?>
        <div class="flex">
            <div class="relative mb-4 flex-1">
                <label for="categoryname" class="label">Category Name<span class="field-required">*</span></label>
                <input name="name" id="categoryname" type="text" class="peer input"
                    placeholder="Enter category name" wire:model="name" />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="relative mb-4 flex-1 ml-5">
                <label for="order" class="label">Category Display Order</label>
                <input name="order" id="order" type="number" class="peer input"
                    placeholder="Enter category display order" wire:model="order" />
                <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <label for="categoryname" class="label">Category Image<span class="field-required">*</span></label>
        <?php if($image): ?>
            <div class="flex flex-col mb-4">
                <img src="<?php echo e($image->temporaryUrl()); ?>" class="w-[200px] h-auto">
                <div class="flex mt-2">
                    <button type="button" class="bg-red-500 text-white px-4 py-2 w-[200px]"
                        wire:click="remove_image">Remove Image</button>
                </div>
            </div>
        <?php else: ?>
            <div class="relative mb-4" x-data="{}">
                <div class="w-full h-40 border border-dashed flex flex-col items-center justify-center cursor-pointer">
                    <button type="button" @click="$refs.image.click()">
                        <div class="h-24 w-24 text-slate-600">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.upload','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    </button>
                    <p class="font-semibold text-md text-slate-600">Click to upload</p>
                </div>
                <input name="image" id="image" type="file" class="hidden" x-ref="image" wire:model="image" />
            </div>
        <?php endif; ?>
        <div class="flex">
            <label>
                <input type="checkbox" class="mr-2" wire:model="isResponsive" value="yes" /> Create reponsive
                images
            </label>
        </div>
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="flex mt-4">
            <button class="primary-button" wire:target="save" wire:loading.attr="disabled">Add
                Category</button>
        </div>
    </form>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/admin/create-category.blade.php ENDPATH**/ ?>