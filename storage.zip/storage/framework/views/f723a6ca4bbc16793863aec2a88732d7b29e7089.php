<section class="w-full relative">
    <img src="/images/home/banner.png" alt="">
    <div class="absolute flex items-center justify-center inset-0 banner-text">
        <p>Each of our <span class="color-red">garments</span> is <span class="color-blue">crafted</span> uniquely and
            exclusively with <span class="color-yellow">hand-painted</span> motifs in-house, ensuring that all our prints
            are <span class="color-orange">developed</span> internally.</p>
    </div>
</section>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/components/public/home/banner.blade.php ENDPATH**/ ?>