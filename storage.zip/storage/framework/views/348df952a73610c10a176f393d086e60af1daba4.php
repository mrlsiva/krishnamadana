<div class="grid grid-cols-4 gap-4 p-12">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col text-center">
            <a href="<?php echo e(route('home.product-details', ['slug' => $product->slug])); ?>" class="product__images__link">
                <div class="relative product__images">
                    <?php $__currentLoopData = $product->media->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($image->original_url); ?>"
                            class="<?php if($loop->first): ?> front-image <?php else: ?> back-image <?php endif; ?>"
                            alt="<?php echo e($product->name); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </a>
            <h2 class="mt-2"><a href=""><?php echo e($product->name); ?></a></h2>
            <p class="price">Rs. <?php echo e($product->display_price); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/category/list-category-products.blade.php ENDPATH**/ ?>