<div class="py-12">
    <form class="flex flex-col items-center justify-center" wire:submit.prevent="submit">
        <h2 class="uppercase text-2xl tracking-widest">Register</h2>
        <p class="my-4 text-gray-700">Please fill in the information below</p>
        <div class="mb-4">
            <input type="text" class="peer input w-96" placeholder="Name" name="name" wire:model.defer="user.name" />
            <?php $__errorArgs = ['user.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-4">
            <input type="text" class="peer input w-96" placeholder="Email" name="email"
                wire:model.defer="user.email" />
            <?php $__errorArgs = ['user.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-4">
            <input type="tel" class="peer input w-96" placeholder="Mobile" maxlength="10" name="mobile"
                wire:model.defer="user.mobile" />
            <?php $__errorArgs = ['user.mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-4">
            <input type="password" class="peer input w-96" placeholder="Password" name="password"
                wire:model.defer="password" />
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-8">
            <input type="password" class="peer input w-96" placeholder="Confirm Password" name="confirm_password"
                wire:model.defer="confirm_password" />
            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="cta-link mb-4 w-96 py-3">Create My Account</button>
        <p class="mt-4">Already registered? <a href="<?php echo e(route('home.login')); ?>">Login Now</a></p>
    </form>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/auth/register.blade.php ENDPATH**/ ?>