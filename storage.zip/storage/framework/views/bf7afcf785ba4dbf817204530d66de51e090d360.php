<div class="w-full md:w-11/12 p-4 mx-auto my-8">
    <div class="flex flex-col items-center justify-center">
        <h2 class="tracking-widest my-4 text-2xl text-slate-600 font-semibold">My Account</h2>
        <p>Welcome, <?php echo e(auth()->user()->name); ?></p>
    </div>
    <div class="flex flex-row mt-8">
        <div class="flex flex-col flex-1">
            <h3 class="w-full pb-4 border-b text-slate-500 text-md mb-4 font-semibold">My Orders</h3>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-col border rounded">
                    <div class="bg-gray-300 flex items-center justify-between p-4 border-b tracking-wider">
                        <div class="flex flex-col">
                            <p class="text-sm uppercase">Order Id</p>
                            <p><?php echo e(Str::replace('order_', '', $order->order_id)); ?></p>
                        </div>
                        <div class="flex flex-col">
                            <p class="text-sm uppercase">Order Placed</p>
                            <p><?php echo e($order->created_at->format('j F, Y')); ?></p>
                        </div>
                        <div class="flex flex-col" x-data="{ tooltip: false }">
                            <p class="text-sm uppercase">Ship To</p>
                            <div class="relative cursor-pointer" x-on:mouseover="tooltip = true"
                                x-on:mouseleave="tooltip = false">
                                <div class="flex text-blue-900"><?php echo e($order->shipping_address->name); ?>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.chevron-down','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.chevron-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div x-show="tooltip"
                                    class="text-sm absolute bg-white rounded-lg p-2
                                transform shadow-lg w-48 -translate-x-8 translate-y-1">
                                    <p><?php echo e($order->shipping_address->name); ?>,</p>
                                    <p class="leading-6"><?php echo e($order->shipping_address->address_line1); ?>,</p>
                                    <?php if($order->shipping_address->address_line2): ?>
                                        <p class="leading-6"><?php echo e($order->shipping_address->address_line2); ?>,</p>
                                    <?php endif; ?>
                                    <?php if($order->shipping_address->landmark): ?>
                                        <p class="leading-6"><?php echo e($order->shipping_address->landmark); ?></p>
                                    <?php endif; ?>
                                    <p class="leading-6"><?php echo e($order->shipping_address->city); ?>,
                                        <?php echo e($order->shipping_address->pincode); ?></p>
                                    <p class="leading-6"><?php echo e($order->shipping_address->state->name); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex">
                        <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col w-full">
                                <p class="px-4 pt-2 text-lg font-bold"><?php echo e($item->statuses->last()->status->status); ?>

                                </p>
                                <div class="flex p-4 w-full">
                                    <img src="<?php echo e($item->product->media[0]->original_url); ?>"
                                        alt="<?php echo e($item->product->name); ?>" class="w-24 h-auto object-cover rounded">
                                    <div class="flex flex-col ms-4 justify-center flex-1">
                                        <p><a href="<?php echo e(route('home.product-details', ['slug' => $item->product->slug])); ?>"
                                                class="text-blue-600 tracking-wider text-md"><?php echo e($item->product->name); ?></a>
                                        </p>
                                        <p><?php echo e($item->variant_name); ?></p>
                                    </div>
                                    <div class="flex flex-col justify-center">
                                        <button class="border px-4 py-2 rounded shadow text-sm">Track Package</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>You have not placed any orders yet.</p>
            <?php endif; ?>

        </div>
        <div class="w-12 mx-4"></div>
        <div class="flex flex-col basis-1/3">
            <h3 class="w-full pb-4 border-b text-slate-500 text-md mb-4 font-semibold">My Addresses</h3>

        <?php if(empty($primary_address)): ?>
            <p>No addresses are saved.</p>
        <?php else: ?>
            <p class="text-xl mb-2"><?php echo e($primary_address->name); ?></p>
            <p class="leading-6">Contact No: <?php echo e($primary_address->mobile); ?></p>
            <p class="leading-6"><?php echo e($primary_address->address_line1); ?></p>
            <p class="leading-6"><?php echo e($primary_address->address_line2); ?></p>
            <p class="leading-6"><?php echo e($primary_address->landmark); ?></p>
            <p class="leading-6"><?php echo e($primary_address->city); ?>, <?php echo e($primary_address->pincode); ?></p>
            <p class="leading-6"><?php echo e($primary_address->state->name); ?></p>
            <?php if($address_count > 0): ?>
                <p class="mt-2 text-gray-500">and <?php echo e($address_count); ?> other
                    <?php echo e(Str::plural('address', $address_count)); ?>.</p>
            <?php endif; ?>
        <?php endif; ?>


        <a class="cta-link px-4 py-3 mt-4" href="<?php echo e(route('home.manage-addresses')); ?>">Manage Addresses</a>
        <h3 class="mt-8 w-full pb-4 border-b text-slate-500 text-md mb-4 font-semibold">Logout</h3>
        <p>Want to Logout and continue as guest?</p>
        <button class="px-4 py-3 border border-red-500 text-red-500 font-semibold mt-4"
            wire:click="logout">Logout</button>
    </div>
</div>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/livewire/public/account/user-account.blade.php ENDPATH**/ ?>