<div class="w-full bg-[#f2cfc9] p-2 text-center">
    <p class="mb-0 text-xs text-primary tracking-widest2">For urgent orders, please whatsapp at +91-93543-59834 | Free
        Shipping in India
        | Free
        International
        Shipping
        above ₹35,000</p>
</div>
<?php /**PATH /home/zzg3h386vagh/public_html/resources/views/components/public/common/announcement.blade.php ENDPATH**/ ?>